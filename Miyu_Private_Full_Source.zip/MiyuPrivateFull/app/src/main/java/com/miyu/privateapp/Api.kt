package com.miyu.privateapp

import okhttp3.MultipartBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

data class ChatRequest(
    val message: String,
    val memory: String,
    val language: String,
    val history: List<HistoryItem>
)
data class HistoryItem(val role: String, val content: String)
data class ChatResponse(val reply: String, val memorySuggestion: String? = null)
data class MemoryRequest(val memory: String)

interface MiyuApi {
    @POST("api/chat")
    suspend fun chat(
        @Header("Authorization") authorization: String,
        @Body request: ChatRequest
    ): ChatResponse

    @Multipart
    @POST("api/image")
    suspend fun image(
        @Header("Authorization") authorization: String,
        @Part image: MultipartBody.Part,
        @Part("prompt") prompt: okhttp3.RequestBody,
        @Part("language") language: okhttp3.RequestBody,
        @Part("memory") memory: okhttp3.RequestBody
    ): ChatResponse
}

object ApiFactory {
    fun create(): MiyuApi = Retrofit.Builder()
        .baseUrl(BuildConfig.MIYU_API_BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(MiyuApi::class.java)
}
