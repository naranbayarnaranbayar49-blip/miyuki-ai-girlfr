package com.miyu.privateapp

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.Locale

data class ChatLine(val role: String, val text: String)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiyuApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiyuApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create() }
    val prefs = remember {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(context, "miyu_private", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    var unlocked by remember { mutableStateOf(false) }
    var firstSetup by remember { mutableStateOf(prefs.getString("pin_hash", null) == null) }
    var pin by remember { mutableStateOf("") }
    var pinEntry by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var memory by remember { mutableStateOf(prefs.getString("memory", "") ?: "") }
    var language by remember { mutableStateOf(prefs.getString("language", "mn-MN") ?: "mn-MN") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatLine>() }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { }
        onDispose { tts?.shutdown() }
    }
    val auth = "Bearer ${BuildConfig.MIYU_DEVICE_TOKEN}"

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            busy = true; error = ""
            try {
                val input = context.contentResolver.openInputStream(uri)!!
                val file = File(context.cacheDir, "miyu_upload.jpg")
                input.use { src -> file.outputStream().use { dst -> src.copyTo(dst) } }
                val body = file.asRequestBody("image/*".toMediaType())
                val part = MultipartBody.Part.createFormData("image", "upload.jpg", body)
                val response = api.image(auth, part,
                    "Энэ зургийг тайлбарлаж, монголоор хариул.".toRequestBody(),
                    language.toRequestBody(), memory.toRequestBody())
                messages.add(ChatLine("assistant", response.reply))
            } catch (e: Exception) { error = "Зураг илгээж чадсангүй: ${e.message}" }
            finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFF08DB9), background = Color(0xFF17111B),
        surface = Color(0xFF251B2B), onPrimary = Color(0xFF25111D)
    )) {
        if (!unlocked) {
            Column(Modifier.fillMaxSize().background(Color(0xFF17111B)).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("♥", color = Color(0xFFF08DB9), style = MaterialTheme.typography.displayLarge)
                Text("MIYU PRIVATE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(if (firstSetup) "Зөвхөн чамд зориулсан хувийн орон зай" else "Нэвтрэх PIN-ээ оруул")
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(value = pinEntry, onValueChange = { if (it.length <= 8 && it.all { ch -> ch.isDigit() }) pinEntry = it },
                    label = { Text("4–8 оронтой PIN") })
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (pinEntry.length !in 4..8) { error = "PIN 4–8 оронтой байх ёстой." }
                    else if (firstSetup) {
                        prefs.edit().putString("pin_hash", pinEntry.hashCode().toString()).apply()
                        firstSetup = false; unlocked = true; pinEntry = ""; error = ""
                    } else if (prefs.getString("pin_hash", "") == pinEntry.hashCode().toString()) {
                        unlocked = true; pinEntry = ""; error = ""
                    } else error = "PIN буруу байна."
                }) { Text(if (firstSetup) "PIN үүсгэх" else "Нээх") }
                if (!error.isBlank()) Text(error, color = Color(0xFFFF9B9B))
                TextButton(onClick = {
                    val manager = BiometricManager.from(context)
                    if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS) {
                        val executor = ContextCompat.getMainExecutor(context)
                        val prompt = BiometricPrompt(context as ComponentActivity, executor, object : BiometricPrompt.AuthenticationCallback() {
                            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true }
                        })
                        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Miyu Private").setSubtitle("Өөрийгөө баталгаажуул").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build())
                    } else error = "Энэ төхөөрөмжид биометр тохируулаагүй байна."
                }) { Text("Хурууны хээ / төхөөрөмжийн түгжээ") }
            }
        } else {
            Scaffold(topBar = {
                TopAppBar(title = { Column { Text("Miyu ♥"); Text("Private AI companion", style = MaterialTheme.typography.labelSmall, color = Color(0xFFF08DB9)) } },
                    actions = {
                        TextButton(onClick = { language = if (language == "mn-MN") "ja-JP" else "mn-MN"; prefs.edit().putString("language", language).apply() }) {
                            Text(if (language == "mn-MN") "MN" else "日本語")
                        }
                        IconButton(onClick = { unlocked = false }) { Icon(Icons.Default.Lock, "Lock") }
                    })
            }, bottomBar = {
                Column(Modifier.navigationBarsPadding().background(Color(0xFF1D1522)).padding(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { imageLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Image, null); Text(" Зураг") }
                        OutlinedButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                            }
                            try { speechLauncher.launch(intent) } catch (_: Exception) { error = "Speech Recognition үйлчилгээ алга." }
                        }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Mic, null); Text(" Ярих") }
                        OutlinedButton(onClick = {
                            if (messages.isNotEmpty()) {
                                val locale = if (language == "ja-JP") Locale.JAPAN else Locale.forLanguageTag("mn-MN")
                                tts?.setLanguage(locale)
                                tts?.speak(messages.last().text, TextToSpeech.QUEUE_FLUSH, null, "miyu_reply")
                            }
                        }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.VolumeUp, null); Text(" Сонсох") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                            placeholder = { Text("Miyu-д бич...") }, maxLines = 4)
                        IconButton(enabled = !busy, onClick = {
                            val text = draft.trim()
                            if (text.isNotEmpty()) {
                                messages.add(ChatLine("user", text)); draft = ""; busy = true; error = ""
                                scope.launch {
                                    try {
                                        val history = messages.takeLast(16).map { HistoryItem(if (it.role == "assistant") "assistant" else "user", it.text) }
                                        val result = api.chat(auth, ChatRequest(text, memory, language, history))
                                        messages.add(ChatLine("assistant", result.reply))
                                        result.memorySuggestion?.let { memory = (memory + "\n" + it).trim(); prefs.edit().putString("memory", memory).apply() }
                                    } catch (e: Exception) { error = "AI сервертэй холбогдож чадсангүй. Серверийн тохиргоогоо шалга. (${e.message})" }
                                    finally { busy = false }
                                }
                            }
                        }) { Icon(Icons.Default.Send, "Send", tint = Color(0xFFF08DB9)) }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B9B), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { memory = ""; prefs.edit().remove("memory").apply() }) { Text("Санах ойг арилгах") }
                }
            }) { padding ->
                LazyColumn(Modifier.fillMaxSize().background(Color(0xFF17111B)).padding(padding).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (messages.isEmpty()) item { Text("Сайн уу. Би Miyu. Монгол эсвэл Япон хэлээр ярилцъя. 💗", color = Color(0xFFE9C8DB)) }
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                            Surface(color = if (msg.role == "user") Color(0xFF9F527C) else Color(0xFF34263B),
                                shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Text(msg.text, Modifier.padding(12.dp), color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
