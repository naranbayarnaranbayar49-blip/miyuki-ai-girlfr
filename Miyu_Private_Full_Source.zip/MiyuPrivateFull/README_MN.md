# Miyu Private — Full Version foundation

Энэ архив нь жинхэнэ Cloud AI холболттой Android аппын эх код + backend API-ийн суурь төсөл. Бэлэн APK биш: сервер байршуулж, API түлхүүр болон төхөөрөмжийн токеныг тохируулсны дараа Android Studio-оор build хийнэ.

## Одоогоор кодонд орсон
- Kotlin + Jetpack Compose Android интерфэйс
- Cloud AI backend (`/api/chat`) — OpenAI Responses API
- Зураг upload + vision endpoint (`/api/image`)
- Монгол/Япон хэл сонгох
- Android speech-to-text launcher, системийн TTS playback
- Android EncryptedSharedPreferences-д PIN болон санах ойн өгөгдөл хадгалах
- PIN түгжээ болон биометрийн нэвтрэх prompt
- Сервер талын bearer device token, rate limit, upload хэмжээний хязгаар

## 1. Backend ажиллуулах
Node.js 20+ суулгана. `server` хавтсанд:
1. `npm install`
2. `.env.example`-ийг `.env` болгож хуул.
3. `OPENAI_API_KEY` дээр өөрийн API түлхүүрээ оруул.
4. `MIYU_DEVICE_TOKEN` дээр урт, санамсаргүй токен үүсгэж оруул.
5. `npm start`

Production-д HTTPS domain ашигла. `.env` файлыг хэзээ ч GitHub-д бүү байршуул. API түлхүүрийг Android апп дотор хийж болохгүй.

## 2. Android тохируулах
1. Android Studio-д төслийн root хавтсыг нээ.
2. `local.properties.example`-ийг `local.properties` болгон хуул.
3. `MIYU_API_BASE_URL`-ийг backend-ийн HTTPS хаягаар (төгсгөлд нь `/`-тэй) солино.
4. `MIYU_DEVICE_TOKEN`-ийг сервер дээрхтэй ижил утгаар солино.
5. Gradle Sync → Build > Build APK(s).

## 3. Ярианы хэл
Аппын дээд хэсгийн `MN / 日本語` товчоор хэлээ соль. Яриа таних болон текст унших чанар нь утсанд суусан Android speech service, TTS engine, тухайн хэлний дэмжлэгээс хамаарна. Монгол TTS бүх төхөөрөмж дээр байх баталгаа байхгүй.

## Чухал хязгаарлалт ба production ажлууд
- Энэ нь build хийх боломжтой эх кодын суурь төсөл; энэ орчноос signed APK гаргаж, утсанд суулгаж туршаагүй.
- Video-call avatar streaming хараахан холбогдоогүй. Үүнд тусгай realtime avatar үйлчилгээ, streaming SDK, тусдаа төлбөр/нууцлалын зөвшөөрөл хэрэгтэй.
- Chat history одоогоор app state-д байна; app дахин нээгдэхэд автоматаар sync хийх production conversation DB хараахан хийгдээгүй.
- PIN hash хэсэг нь demo түвшний PIN шалгалт; biometric prompt системийн төхөөрөмжийн credential-ийг ашиглана. Production-д PIN verification-ийг PBKDF2/Argon2 + Keystore key хамгаалалтаар сайжруул.
- Device token APK-д орвол reverse engineering-ээр гаргаж авч болно. Жинхэнэ production хэрэглээнд per-device enrollment, revocation, short-lived token хэрэгтэй.
- API usage төлбөртэй байж болно; OpenAI API billing нь ChatGPT захиалгаас тусдаа.
- Нууц мэдээлэл, хувийн зураг сервер рүү явж AI-д боловсруулагдана. Хэрэглэгч үүнийг мэдэж, зөвшөөрсөн байх ёстой.
- AI-ийн хариулт насанд хүрэгчдийн ил тод эротик дүрслэлд зориулагдаагүй; романтик, сээтэгнүүр боловч non-explicit байдлаар тохируулсан.

## Файлын бүтэц
- `app/` Android Kotlin application
- `server/` Cloud AI backend
- `local.properties.example` Android endpoint + төхөөрөмжийн токены жишээ
